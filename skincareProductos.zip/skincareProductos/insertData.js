const fs = require('fs');
const path = require('path');
const productosModel = require('./src/models/productosModel');

// Lista de columnas obligatorias (según la estructura de la tabla)
const requiredFields = [
  "product_id",
  "product_name",
  "brand_id",
  "brand_name",
  "ingredients",
  "primary_category",
  "secondary_category",
  "tertiary_category",
  "price_usd",
  "size",
  "characteristics",
  "highlights",
  "online_only",
  "limited_edition",
  "new",
  "sephora_exclusive",
  "out_of_stock"
];

// Ruta al archivo JSON generado
const filePath = path.join(__dirname, 'product_info_filtered.json');

// Leer el archivo JSON
fs.readFile(filePath, 'utf8', (err, data) => {
  if (err) {
    console.error('❌ Error al leer el archivo JSON:', err);
    return;
  }
  
  let productos;
  try {
    productos = JSON.parse(data);
  } catch (parseError) {
    console.error('❌ Error al parsear el JSON:', parseError);
    return;
  }
  
  // Insertar cada producto en la base de datos
  productos.forEach((producto, index) => {
    // Verificar si faltan campos obligatorios o alguno es null/undefined
    const missingFields = requiredFields.filter(field => producto[field] === null || producto[field] === undefined);
    
    if (missingFields.length > 0) {
      console.warn(`⚠️ Registro en índice ${index} no insertado. Campos faltantes o nulos: ${missingFields.join(', ')}`);
      return; // Se omite la inserción para este producto
    }
    
    // Insertar el producto
    productosModel.addProduct(producto, (err, result) => {
      if (err) {
        console.error(`❌ Error al insertar producto en el índice ${index}:`, err);
      } else {
        console.log(`✅ Producto insertado correctamente: ${producto.product_id}`);
      }
    });
  });
});
