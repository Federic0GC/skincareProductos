const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'sephoraProductos'
});

db.connect((err) => {
    if (err) {
        console.error('❌ Error al conectar a MariaDB:', err);
        return;
    }
    console.log('✅ Conectado a MariaDB');
});

// Agregar un producto (se incluye product_id porque NO es autoincrement)
const addProduct = (newProduct, callback) => {
    const sql = `
        INSERT INTO productos (
            product_id,
            product_name,
            brand_id,
            brand_name,
            ingredients,
            primary_category,
            secondary_category,
            tertiary_category,
            price_usd,
            size,
            characteristics,
            highlights,
            online_only,
            limited_edition,
            new,
            sephora_exclusive,
            out_of_stock
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
        newProduct.product_id,                    // <--- IMPORTANTE: IDs tipo "P473671"
        newProduct.product_name,
        newProduct.brand_id,
        newProduct.brand_name,
        newProduct.ingredients,
        newProduct.primary_category,
        newProduct.secondary_category,
        newProduct.tertiary_category,
        newProduct.price_usd,
        newProduct.size,
        JSON.stringify(newProduct.characteristics), // Convertimos array a JSON
        newProduct.highlights,
        newProduct.online_only,
        newProduct.limited_edition,
        newProduct.new,
        newProduct.sephora_exclusive,
        newProduct.out_of_stock
    ];

    db.query(sql, values, callback);
};

// Obtener todos los productos
const getAllProducts = (callback) => {
    const sql = 'SELECT * FROM productos';
    db.query(sql, callback);
};

// Obtener un producto por ID
const getProductById = (productId, callback) => {
    const sql = 'SELECT * FROM productos WHERE product_id = ?';
    db.query(sql, [productId], callback);
};

// Eliminar un producto
const deleteProduct = (productId, callback) => {
    const sql = 'DELETE FROM productos WHERE product_id = ?';
    db.query(sql, [productId], callback);
};

// Actualizar un producto (incluyendo product_id si quieres cambiarlo)
const updateProduct = (oldProductId, updatedProduct, callback) => {
    const sql = `
        UPDATE productos
        SET
            product_id = ?,
            product_name = ?,
            brand_id = ?,
            brand_name = ?,
            ingredients = ?,
            primary_category = ?,
            secondary_category = ?,
            tertiary_category = ?,
            price_usd = ?,
            size = ?,
            characteristics = ?,
            highlights = ?,
            online_only = ?,
            limited_edition = ?,
            new = ?,
            sephora_exclusive = ?,
            out_of_stock = ?
        WHERE product_id = ?
    `;

    const values = [
        updatedProduct.product_id,                     // Nuevo ID (por si deseas cambiarlo)
        updatedProduct.product_name,
        updatedProduct.brand_id,
        updatedProduct.brand_name,
        updatedProduct.ingredients,
        updatedProduct.primary_category,
        updatedProduct.secondary_category,
        updatedProduct.tertiary_category,
        updatedProduct.price_usd,
        updatedProduct.size,
        JSON.stringify(updatedProduct.characteristics),
        updatedProduct.highlights,
        updatedProduct.online_only,
        updatedProduct.limited_edition,
        updatedProduct.new,
        updatedProduct.sephora_exclusive,
        updatedProduct.out_of_stock,
        oldProductId                                   // ID actual (en la cláusula WHERE)
    ];

    db.query(sql, values, callback);
};

module.exports = {
    addProduct,
    getAllProducts,
    getProductById,
    deleteProduct,
    updateProduct
};
