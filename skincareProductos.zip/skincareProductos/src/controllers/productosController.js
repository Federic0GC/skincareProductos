const express = require('express');
const router = express.Router();
const productosModel = require('../models/productosModel');

// Agregar un producto
router.post('/', (req, res) => {
    const nuevoProducto = req.body;
    productosModel.addProduct(nuevoProducto, (err, result) => {
        if (err) {
            console.error('❌ Error al agregar producto:', err);
            return res.status(500).json({ message: 'Error al agregar producto' });
        }
        // insertId suele ser 0 cuando la PK no es autoincrement
        res.status(201).json({ message: '✅ Producto agregado correctamente', productId: nuevoProducto.product_id });
    });
});

// Obtener todos los productos
router.get('/', (req, res) => {
    productosModel.getAllProducts((err, results) => {
        if (err) {
            console.error('❌ Error al obtener productos:', err);
            return res.status(500).json({ message: 'Error al obtener productos' });
        }
        res.json(results);
    });
});

// Obtener un producto por ID
router.get('/:id', (req, res) => {
    const productId = req.params.id;
    productosModel.getProductById(productId, (err, results) => {
        if (err) {
            console.error('❌ Error al obtener el producto:', err);
            return res.status(500).json({ message: 'Error al obtener el producto' });
        } else if (!results || results.length === 0) {
            return res.status(404).json({ message: '❌ Producto no encontrado' });
        }
        res.json(results[0]);
    });
});

// Actualizar un producto (incluyendo product_id)
router.put('/:oldId', (req, res) => {
    const oldProductId = req.params.oldId; // El ID actual del producto
    const updatedProduct = req.body;       // Datos con el nuevo product_id (si quieres cambiarlo)
    productosModel.updateProduct(oldProductId, updatedProduct, (err, result) => {
        if (err) {
            console.error('❌ Error al actualizar el producto:', err);
            return res.status(500).json({ message: 'Error al actualizar el producto' });
        } else if (result.affectedRows === 0) {
            return res.status(404).json({ message: '❌ Producto no encontrado' });
        }
        res.json({ message: '✅ Producto actualizado correctamente' });
    });
});

// Eliminar un producto
router.delete('/:id', (req, res) => {
    const productId = req.params.id;
    productosModel.deleteProduct(productId, (err, result) => {
        if (err) {
            console.error('❌ Error al eliminar el producto:', err);
            return res.status(500).json({ message: 'Error al eliminar el producto' });
        } else if (result.affectedRows === 0) {
            return res.status(404).json({ message: '❌ Producto no encontrado' });
        }
        res.json({ message: '✅ Producto eliminado correctamente' });
    });
});

module.exports = router;
